# Docs

Documents are not necessarily updated synchronously, slower than godoc, please see examples and godoc.